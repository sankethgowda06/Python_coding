
# Honeycomb AI Bot (Python Backend)

## Setup

1. Install dependencies:
   pip install -r requirements.txt

2. Set environment variables:

   AWS_REGION=us-east-1
   BEDROCK_MODEL_ID=your_model_id
   HONEYCOMB_API_KEY=your_key
   HONEYCOMB_DATASET=your_dataset

3. Run:
   python app.py

4. Test:
   POST http://localhost:3000/chat
   Body:
   { "message": "Show errors in payment service" }
