
import os
import json
import boto3
import requests
from flask import Flask, request, jsonify

app = Flask(__name__)

bedrock = boto3.client("bedrock-runtime", region_name=os.getenv("AWS_REGION"))

MODEL_ID = os.getenv("BEDROCK_MODEL_ID")
HONEYCOMB_API_KEY = os.getenv("HONEYCOMB_API_KEY")
HONEYCOMB_DATASET = os.getenv("HONEYCOMB_DATASET")

def call_bedrock(prompt, max_tokens=500):
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens
    }

    response = bedrock.invoke_model(
        modelId=MODEL_ID,
        contentType="application/json",
        accept="application/json",
        body=json.dumps(body)
    )
    result = json.loads(response["body"].read())
    return result["content"][0]["text"]

def generate_honeycomb_query(user_question):
    prompt = f'''
Convert this into a Honeycomb query filter:

Question: "{user_question}"

Return ONLY JSON:
{{
  "filters": [
    {{ "column": "...", "op": "...", "value": "..." }}
  ],
  "time_range_minutes": 60
}}
'''
    text = call_bedrock(prompt)
    return json.loads(text)

def query_honeycomb(query_json):
    url = f"https://api.honeycomb.io/v1/query/{HONEYCOMB_DATASET}"
    body = {
        "calculations": [{"op": "COUNT"}],
        "filters": query_json["filters"],
        "time_range": query_json["time_range_minutes"] * 60
    }

    headers = {
        "X-Honeycomb-Team": HONEYCOMB_API_KEY,
        "Content-Type": "application/json"
    }

    res = requests.post(url, headers=headers, json=body)
    return res.json()

def analyze_results(user_question, honey_data):
    prompt = f'''
User question:
{user_question}

Honeycomb data:
{json.dumps(honey_data, indent=2)}

Explain:
- What is failing
- Which service
- Possible reason
- Suggested next steps
'''
    return call_bedrock(prompt, max_tokens=700)

@app.route("/chat", methods=["POST"])
def chat():
    try:
        user_question = request.json.get("message")
        honey_query = generate_honeycomb_query(user_question)
        honey_result = query_honeycomb(honey_query)
        answer = analyze_results(user_question, honey_result)
        return jsonify({"reply": answer})
    except Exception as e:
        print(e)
        return jsonify({"error": "Failed"}), 500

if __name__ == "__main__":
    app.run(port=3000)
